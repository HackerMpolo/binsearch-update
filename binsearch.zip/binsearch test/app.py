from flask import Flask, request, render_template, redirect, url_for, flash, session
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FileField, PasswordField
from wtforms.validators import InputRequired
from flask_wtf.csrf import CSRFProtect
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
csrf = CSRFProtect(app)

class PasteForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired()])
    content = TextAreaField('Content', validators=[InputRequired()])
    file = FileField('File')

class AdminLoginForm(FlaskForm):
    password = PasswordField('Password', validators=[InputRequired()])

def get_client_ip():
    # Vérifiez les en-têtes HTTP courants pour les proxys inverses
    if request.environ.get('HTTP_X_FORWARDED_FOR'):
        ip = request.environ['HTTP_X_FORWARDED_FOR']
        ip = ip.split(',')[0]
    elif request.environ.get('HTTP_X_REAL_IP'):
        ip = request.environ['HTTP_X_REAL_IP']
    else:
        ip = request.remote_addr
    return ip

@app.route('/', methods=['GET', 'POST'])
def index():
    form = PasteForm()
    if form.validate_on_submit():
        username = form.username.data
        if username.lower() == 'admin':
            flash("Username 'admin' is not allowed", 'danger')
            return redirect(url_for('index'))
        content = form.content.data
        file = form.file.data

        if file:
            file.save(os.path.join('uploads', file.filename))
            content += f' (File: {file.filename})'

        ip = get_client_ip()
        with open('messages.txt', 'a') as f:
            f.write(f'{username}: {content}\n')
        with open('ips.txt', 'a') as f:
            f.write(f'{ip}\n')

        flash('Message posted!', 'success')
        return redirect(url_for('index'))

    messages = []
    if os.path.exists('messages.txt'):
        with open('messages.txt', 'r') as f:
            messages = f.readlines()

    return render_template('index.html', form=form, messages=messages)

@app.route('/2201097872071813414321201158532231317532098318542446329002', methods=['GET', 'POST'])
def admin_panel():
    if 'logged_in' not in session or not session['logged_in']:
        return redirect(url_for('login'))
    
    form = PasteForm()  # Placeholder form for CSRF token
    if request.method == 'POST':
        ip_to_ban = request.form.get('ip_to_ban')
        if ip_to_ban:
            with open('banned_ips.txt', 'a') as f:
                f.write(f'{ip_to_ban}\n')
            flash(f'IP {ip_to_ban} banned!', 'success')
        
        message_to_delete = request.form.get('message_to_delete')
        if message_to_delete:
            with open('messages.txt', 'r') as f:
                messages = f.readlines()
            with open('messages.txt', 'w') as f:
                for message in messages:
                    if message_to_delete not in message:
                        f.write(message)
            flash('Message deleted!', 'success')
    
    messages_with_ips = []
    if os.path.exists('messages.txt') and os.path.exists('ips.txt'):
        with open('messages.txt', 'r') as mf, open('ips.txt', 'r') as ipf:
            messages = mf.readlines()
            ips = ipf.readlines()
            messages_with_ips = zip(messages, ips)
    
    banned_ips = []
    if os.path.exists('banned_ips.txt'):
        with open('banned_ips.txt', 'r') as f:
            banned_ips = f.readlines()

    return render_template('admin_panel.html', form=form, messages_with_ips=messages_with_ips, banned_ips=banned_ips)

@app.route('/294687790149333269819502642117160237881100212299681204724501133172513924062141723212146127132753524684\11675', methods=['GET', 'POST'])
def login():
    form = AdminLoginForm()
    if form.validate_on_submit():
        if form.password.data == '54511467317555293735788137514756112871335456633082253908399507414432626071061706120323263392493755\17504':
            session['logged_in'] = True
            return redirect(url_for('admin_panel'))
        else:
            flash('Invalid password', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True)
